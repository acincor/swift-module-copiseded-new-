import subprocess
class module:
    def main():
        print("This app is Copyright © MHC Inc in 2022.5.22.13:53, This is The sixth app\nMIT License\nCopyright © 2022 monkeyhammercopiseded\nPermission is hereby granted, free of charge, to any person obtaining a copy\nof this software and associated documentation files (the \"Software\"), to deal\nin the Software without restriction, including without limitation the rights\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\ncopies of the Software, and to permit persons to whom the Software is\nfurnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all\ncopies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\nSOFTWARE.")
    def caterpillar():
        from swift_apple import caterpillar
    def 单词九连猜():
        from swift_apple import 单词九连猜
    def nineWordGuessing():
        from swift_apple import 单词九连猜
    def 加密消息():
        from swift_apple import 加密消息
    def secretMessage():
        from swift_apple import 加密消息
    def snap():
        from swift_apple import 快照抓拍
    def 快照抓拍():
        from swift_apple import 快照抓拍
    def 螺旋万花筒():
        from swift_apple import 螺旋万花筒
    def spiralKaleidoscope():
        from swift_apple import 螺旋万花筒
    def 星光夜空():
        from swift_apple import 星光夜空
    def starlightNight():
        from swift_apple import 星光夜空
    def 圆筒万花筒():
        from swift_apple import 圆筒万花筒
    def cylinderKaleidoscope():
        from swift_apple import 圆筒万花筒
    def animal_guess():
        from swift_apple import animal_guess
    def caterpillar2():
        from swift_apple import caterpillar2
    def copyright():
        from swift_apple import copyright
    def eggCatcherPerfect():
        from swift_apple import egg_catcher_perfect
    def eggCatcher():
        from swift_apple import egg_catcher
    def GuessGame():
        from swift_apple import GuessGame
    def GuessGameEasy():
        from swift_apple import GuessGameEasy
    def GuessGameSecondary():
        from swift_apple import GuessGameSecondary
    def matchmaker():
        from swift_apple import matchmaker
    def MITLicense():
        from swift_apple import MITLicense
    def PHYSICAL_CONDITION_APPLET():
        from swift_apple import PHYSICAL_CONDITION_APPLET
    def Python3学习示例():
        from swift_apple import Python3学习示例
    def random():
        from swift_apple import random
    def rectangle():
        from swift_apple import rectangle
    def robotBuilder():
        from swift_apple import robot_builder
    def screenPet():
        from swift_apple import screen_pet
    def swift():
        from swift_apple import swift
