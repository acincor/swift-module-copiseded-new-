#Swift Apple

This swift(module) is a swift-calculate app.


Installation
---------------

1.You can use [Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/) to write your content.You can use:

   ```shell```

      $ python3 -m pip install swift-module-copiseded --upgrade

  to update.


2.And if you are frist use the module you can use:

  ```shell```

      $ python3 -m pip install swift-module-copiseded

 to get it.

3.And I add some new project[randomInt(),squareRoot(),squareOfANumber()],have a fun!

12 Games
---------------
1.you can use:

   ```shell```
      
       $ from swift_apple import GameName
or:

   ```shell```
      
       import swift_apple
       swift_apple.module.GameName

GameName:

  ```shell```
        
      单词九连猜(),nineWordGuessing(),加密消息(),secretMessage(),快照抓拍(),snap(),螺旋万花筒(),spiralKaleidoscope(),animal_guess(),星光夜空(),starlightNight(),caterpillar(),caterpillar(),eggCatcher(),rectangle(),robotBuilder(),eggCatcherPerfect(),PHYSICAL_CONDITION_APPLET(),matchmaker(),screen_pet()
    

in python

  ```shell```

        $ GameName is a module


and the swift_apple has

   ```shell```

        单词九连猜.py,加密消息.py,快照抓拍.py,螺旋万花筒.py,animal_guess.py,星光夜空.py,caterpillar.py,caterpillar2.py,egg_catcher.py,rectangle.py,robot_builder.py,egg_catcher_perfect.py,PHYSICAL_CONDITION_APPLET.py,matchmaker.py,screen_pet.py

 Upload:

  ```shell```

      import swift_apple
      swift_apple.module.main()

Main() is used to describe copyright. You can also use

   ```shell```

      from swift_apple import copyright
      copyright.copyright_Swift()
      
Tips
-------

-  You can use ⬅️⬆️➡️⬇️ keys or '1234' keys to remove the blocks on the
   caterpillar2's screen

-  Screenshot will be saved to ' ~/Desktop/Swift-Apple/screenshots '
