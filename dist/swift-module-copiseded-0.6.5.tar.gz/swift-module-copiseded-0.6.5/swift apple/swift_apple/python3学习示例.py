import os
def HELLOWORLD():
    display = 'print(\'hello,world\')\nperson=input(\'what\\\'s your name?\')\nprint(\'hello,\',person)'
    displayString = '结果：\n>>>print(\'hello,world\')\nhello,world\n>>>person=input(\'what\\\'s your name?\')\nwhat\'s your name?copiseded(你可以输入你自己的名字)\nprint(\'hello,\',person)\nhello,lin'
    print(display)
    print(displayString)
def IF_ELSE():
    print('weather = input(\'How is the weather?rain/sunny/cold: \')\nif weather == \'rain\':\n    print(\'I\\\'m disappointed\')\nelif weather == \'cold\':    print(\'I\\\'m disappointed\')else:\n    print(\'Come on the play with me.\')')
    print('结果：\n>>>weather = input(\'How is the weather?rain/sunny/cold: \')\nHow is the weather?rain/sunny/cold:\n>>>rain\nI\'m disappointed')
IF_ELSE()
